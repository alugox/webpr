    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link href="/descargas/componentes/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://code.jquery.com/jquery-2.2.0.min.js"></script>
    <script src="/descargas/componentes/bootstrap/js/bootstrap.min.js"></script>
    
    <b>SALVADOR HAIRDRESSING - MISTERY SHOPPER</b><br><br>