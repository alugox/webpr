<?php
function enviarMail($user, $id){
$to = 'alugox@gmail.com';
$subject = "Beautiful HTML Email using PHP by CodexWorld";

$htmlContent = '
    <html>
    <head>
        <title>Welcome to CodexWorld</title>
    </head>
    <body>
        <h1>Thanks you for joining with us!</h1>
        <table cellspacing="0" style="border: 2px dashed #FB4314; width: 300px; height: 200px;">
            <tr>
                <th>Name:</th><td>CodexWorld</td>
            </tr>
            <tr style="background-color: #e0e0e0;">
                <th>Email:</th><td>contact@codexworld.com</td>
            </tr>
            <tr>
                <th>Website:</th><td><a href="http://www.codexworld.com">www.codexworld.com</a></td>
            </tr>
        </table>
    </body>
    </html>';

// Set content-type header for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From: Armando<alugox@gmail.com>' . "\r\n";
$headers .= 'Cc: arm_lug@outlook.com' . "\r\n";
//$headers .= 'Bcc: welcome2@example.com' . "\r\n";

// Send email
if(mail($to,$subject,$htmlContent,$headers)):
    $successMsg = 'Email has sent successfully.';
else:
    $errorMsg = 'Email sending fail.';
endif;
echo "El estado del mensaje es: <br>Exitoso = $successMsg<br><br>Fallo = $errorMsg";
}

function enviarMailBienvenida($email, $password){
$to = $email;
$subject = "Salvador Hairdressing: Mystery Shopper - Bienvenido";

$htmlContent = file_get_contents("../etc/correos/bienvenido.php");

// Set content-type header for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From: Salvador Hairdressing<noreply@salvadorhairdressing.com>' . "\r\n";
//$headers .= 'Cc: arm_lug@outlook.com' . "\r\n";
//$headers .= 'Bcc: welcome2@example.com' . "\r\n";

// Send email
if(mail($to,$subject,$htmlContent,$headers)):
        $msg = "¡Participante Aprobado Éxitosamente! Este recibirá un correo siendo informado.<br>";
        $clase = "alert alert-success alert-dismissable fade in";
else:
        $msg = "<strong>Error</strong> al enviar Correo Informativo al Cliente.<br>";
        $clase = "alert alert-danger alert-dismissable fade in";  
endif;
echo "<div class='$clase'>
        <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
        $msg</div>";   
}

function enviarRecordatorioBanco($user){
    $to = $user;
    $subject = "Salvador Hairdressing: Mystery Shopper - Completa tu Información Bancaria";

    $htmlContent = file_get_contents("../etc/correos/datosbancarios.php");

    // Set content-type header for sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    // Additional headers
    $headers .= 'From: Salvador Hairdressing<noreply@salvadorhairdressing.com>' . "\r\n";
    //$headers .= 'Cc: arm_lug@outlook.com' . "\r\n";
    //$headers .= 'Bcc: welcome2@example.com' . "\r\n";

    // Send email
    if(mail($to,$subject,$htmlContent,$headers)):
        $msg = "Correo Recordatorio al Cliente fue <strong>Enviado Éxitosamente</strong>.<br>";
        $clase = "alert alert-success alert-dismissable fade in";
    else:
        $msg = "<strong>Error</strong> al enviar Correo Recordatorio al Cliente.<br>";
        $clase = "alert alert-danger alert-dismissable fade in";  
    endif;
    
    echo "<div class='$clase'>
        <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
        $msg</div>";
}

function enviarNuevaCita($user){
    $to = $user;
    $subject = "Salvador Hairdressing: Mystery Shopper - ¡Nueva Cita!";

    $htmlContent = file_get_contents("../etc/correos/nuevacita.php");

    // Set content-type header for sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    // Additional headers
    $headers .= 'From: Salvador Hairdressing<noreply@salvadorhairdressing.com>' . "\r\n";
    //$headers .= 'Cc: arm_lug@outlook.com' . "\r\n";
    //$headers .= 'Bcc: welcome2@example.com' . "\r\n";

    // Send email
    if(mail($to,$subject,$htmlContent,$headers)):
        $msg = "<strong>¡La visita fue programada éxitosamente!</strong><br><br>El correo con Aviso de Nueva Cita fue enviado al Cliente <strong>Éxitosamente</strong>.<br>";
        $clase = "alert alert-success alert-dismissable fade in";
    else:
        $msg = "<strong>Error</strong> al enviar Correo de Aviso al Cliente.<br>";
        $clase = "alert alert-danger alert-dismissable fade in";  
    endif;
    
    echo "<div class='$clase'>
        <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
        $msg</div>";    
}

function enviarAvisoNuevoUsuario(){
    $to = "sistemas@salvadorhairdressing.com";
    $subject = "Salvador Hairdressing: Mystery Shopper - ¡Nueva Solicitud de Participante!";

    $htmlContent = file_get_contents("../etc/correos/nuevoregistro.php");

    // Set content-type header for sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    // Additional headers
    $headers .= 'From: Salvador Hairdressing<noreply@salvadorhairdressing.com>' . "\r\n";
    $headers .= 'Cc: programacion@salvadorhairdressing.com' . "\r\n";
    //$headers .= 'Bcc: welcome2@example.com' . "\r\n";

    // Send email
    if(mail($to,$subject,$htmlContent,$headers)):
        //header('location: /mysteryshopper/index.php?e=1');
        include '../index.php?e=1';
//
//        $msg = "<strong>¡La visita fue programada éxitosamente!</strong><br><br>El correo con Aviso de Nueva Cita fue enviado al Cliente <strong>Éxitosamente</strong>.<br>";
//        $clase = "alert alert-success alert-dismissable fade in";
    else:
        header('location: /mysteryshopper/index.php?e=0');
//        $msg = "<strong>Error</strong> al enviar Correo de Aviso al Cliente.<br>";
//        $clase = "alert alert-danger alert-dismissable fade in";  
    endif;
    
//    echo "<div class='$clase'>
//        <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
//        $msg</div>";    
}


function getCorreo($idp){
    require_once "../../sitio/sec/ms/libcon.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($dbh));
        exit;
    }
    $email = "";

    $sql = "SELECT correo FROM ms_usuario WHERE id = $idp LIMIT 1";
    $search = mysqli_query($dbh, $sql);
    $match = mysqli_num_rows($search);
    if ($match > 0) {
            while ($rw = mysqli_fetch_array($search)) {
                $email = $rw['correo'];
                return $email;
            }
    } else{
        //NO HAY CORREO
    }
}

function getPassword($idp){
    require_once "../../sitio/sec/ms/libcon.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($dbh));
        exit;
    }
    $pass = "";

    $sql = "SELECT password FROM ms_usuario WHERE id = $idp LIMIT 1";
    $search = mysqli_query($dbh, $sql);
    $match = mysqli_num_rows($search);
    if ($match > 0) {
            while ($rw = mysqli_fetch_array($search)) {
                $pass = $rw['password'];
                return $pass;
            }
    } else{
        //NO HAY CORREO
    }
}

?>
